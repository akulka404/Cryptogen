print("Name: Aniruddha Kulkarni")
print("Email: aniruddha.k1911@gmail.com")
